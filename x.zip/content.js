let isPlaying = false;
let currentAudio = null;
let audioQueue = [];

const btn = document.createElement('div');
btn.innerHTML = '▶';
btn.style.cssText = `position: fixed; bottom: 25px; right: 25px; width: 55px; height: 55px; background: #6366f1; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 24px; box-shadow: 0 4px 15px rgba(99,102,241,0.4); z-index: 999999;`;
document.body.appendChild(btn);

async function playNext() {
    if (!isPlaying || audioQueue.length === 0) {
        isPlaying = false;
        btn.innerHTML = '▶';
        return;
    }

    const text = audioQueue.shift();
    btn.innerHTML = '⏳';

    chrome.runtime.sendMessage({action: "fetchAudio", text}, (res) => {
        if (!res || !res.audioBase64 || !isPlaying) return;

        currentAudio = new Audio("data:audio/mp3;base64," + res.audioBase64);
        btn.innerHTML = '⏸';
        currentAudio.play();
        currentAudio.onended = playNext;
    });
}

btn.onclick = () => {
    if (isPlaying) {
        isPlaying = false;
        if (currentAudio) currentAudio.pause();
        btn.innerHTML = '▶';
    } else {
        isPlaying = true;
        // Collect paragraphs fresh every time
        audioQueue = Array.from(document.querySelectorAll('p'))
                          .map(p => p.innerText.trim())
                          .filter(t => t.length > 50);
        playNext();
    }
};