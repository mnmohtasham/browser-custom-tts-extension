// options.js
document.addEventListener('DOMContentLoaded', () => {
    const apiUrlInput = document.getElementById('apiUrl');
    const voiceIdInput = document.getElementById('voiceId');
    const saveBtn = document.getElementById('save');

    // Load saved settings
    chrome.storage.local.get(['apiUrl', 'voiceId'], (data) => {
        apiUrlInput.value = data.apiUrl || "https://tts.selfhostapps.com";
        voiceIdInput.value = data.voiceId || "af_bella";
    });

    // Save settings
    saveBtn.addEventListener('click', () => {
        chrome.storage.local.set({
            apiUrl: apiUrlInput.value,
            voiceId: voiceIdInput.value
        }, () => {
            saveBtn.textContent = "Saved!";
            setTimeout(() => saveBtn.textContent = "Save", 2000);
        });
    });
});